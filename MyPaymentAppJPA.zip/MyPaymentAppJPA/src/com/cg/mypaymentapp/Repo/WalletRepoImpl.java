package com.cg.mypaymentapp.Repo;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.service.WalletServiceImpl;
import com.cg.mypaymentapp.util.ConnectionSQL;

public class WalletRepoImpl implements WalletRepo {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("newJPA");
	EntityManager em = emf.createEntityManager();
	EntityTransaction tr = em.getTransaction();

	public WalletRepoImpl() {
		super();

	}

	public boolean save(Customer customer) throws Exception {

		tr.begin();
		em.persist(customer);
		tr.commit();
		return true;
	}

	public Customer findOne(String mobileNo) throws SQLException {
		tr.begin();
		Customer customer = em.find(Customer.class, mobileNo);
		tr.commit();
		return customer;
		
	}

	@Override
	public void update(Customer customer) throws SQLException {
		tr.begin();
		em.merge(customer);
		tr.commit();
	}

}
