package com.cg.mypaymentapp.beans;

import java.math.BigDecimal;



import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Wallet {
	private BigDecimal balance;
	@Id
	int walletId;

	public int getWalletId() {
		return walletId;
	}

	public void setWalletId(int walletId) {
		this.walletId = walletId;
	}

	public Wallet(BigDecimal amount, int id) {
		super();
		this.balance=amount;
		this.walletId=id;
	
	}

	public Wallet(BigDecimal amount) {
		this.balance = amount;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public Wallet() {
		super();
	}

	@Override
	public String toString() {
		return "balance=" + balance + ", walletId=" + walletId;
	}

}
