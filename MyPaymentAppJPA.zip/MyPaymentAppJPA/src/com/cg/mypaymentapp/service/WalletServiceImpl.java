package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import javax.naming.InvalidNameException;
import javax.swing.plaf.synth.SynthStyle;

import com.cg.mypaymentapp.Exception.InsufficientBalanceException;
import com.cg.mypaymentapp.Exception.InvalidInputException;
import com.cg.mypaymentapp.Repo.WalletRepo;
import com.cg.mypaymentapp.Repo.WalletRepoImpl;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.pl.Client;
import com.mysql.jdbc.StandardSocketFactory;

public class WalletServiceImpl implements WalletService {

	private WalletRepo repo;

	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}

	public WalletServiceImpl() {
		repo = new WalletRepoImpl();
	}

	Scanner console = new Scanner(System.in);

	public Customer createAccount(String name, String mobileNo,
			BigDecimal amount) throws Exception {

		while (true) {
			try {
				if (validation(mobileNo))
					break;
				else {
					throw new InvalidInputException(
							"Enter valid mobile number of 10 digits:");
				}

			} catch (InvalidInputException e) {

				System.err.println(e.getMessage());

				mobileNo = console.next();
				break;
			}

		}
		while (true) {
			try {
				if (validationName(name)) {

					break;
				} else {
					throw new InvalidInputException(
							"Name should start with a capital letter");
				}
			} catch (InvalidInputException e) {
				System.err.println(e.getMessage());
				name = console.next();
				break;

			}

		}
		int id = (int) (Math.random() * 100);
		Customer customer = new Customer(name, mobileNo, new Wallet(amount, id));
		boolean cust = repo.save(customer);
		repo.update(customer);
		if (cust == true) {

			return customer;
		} else {
			return null;
		}
	}

	private boolean validationName(String name) {
		String pattern1 = "[A-Z][a-zA-Z]*";
		if (name.matches(pattern1)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean validation(String mobileNo) throws Exception {

		String pattern = "[7-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]";
		if (mobileNo.matches(pattern)) {
			return true;

		} else
			return false;

	}

	public Customer showBalance(String mobileNo) throws Exception {
		int flag = 0;
		while (true && (flag < 3)) {

			if (validation(mobileNo)) {
				Customer customer = repo.findOne(mobileNo);
				if (customer != null) {
					System.out.println(customer);
					return customer;
				} else {
					throw new InvalidInputException("invalid ");

				}
			} else {
				flag++;
				System.out.println("enter proper 10 digit mobile number:");
				mobileNo = console.next();
			}

		}
		return null;

	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			BigDecimal amount) throws InvalidInputException, SQLException {
		try {
			Customer customer21 = repo.findOne(sourceMobileNo);
			Customer customer22 = repo.findOne(targetMobileNo);
			if ((customer21 != null) && (customer22 != null)) {
				Customer wcustomer = withdrawAmount(sourceMobileNo, amount);
				Customer dcustomer = depositAmount(targetMobileNo, amount);
			return dcustomer;
			}

		} catch (InvalidInputException e) {
			throw new InvalidInputException();
		}
		return null;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount)
			throws InvalidInputException, SQLException {
		Customer dcustomer = repo.findOne(mobileNo);
		try {
			if (dcustomer != null) {
				Wallet iAmount = dcustomer.getWallet();
				int id = iAmount.getWalletId();
				BigDecimal updatedBalance = iAmount.getBalance().add(amount);
				Wallet wallet = new Wallet(updatedBalance, id);
				dcustomer.setWallet(wallet);
				repo.update(dcustomer);
			}
		} catch (InvalidInputException e) {
			throw new InvalidInputException();
		}
		return dcustomer;

	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount)
			throws InsufficientBalanceException, SQLException {
		Customer wcustomer = repo.findOne(mobileNo);
		System.out.println("source:" + wcustomer);
		try {
			if (wcustomer != null) {
				Wallet iAmount = wcustomer.getWallet();
				int id = iAmount.getWalletId();
				BigDecimal updatedBalance = iAmount.getBalance().subtract(
						amount);
				Wallet wallet = new Wallet(updatedBalance, id);
				wcustomer.setWallet(wallet);
				repo.update(wcustomer);
				return wcustomer;
			} else {
				return null;
			}
		} catch (InsufficientBalanceException e) {
			throw new InsufficientBalanceException();
		}
	}

}
